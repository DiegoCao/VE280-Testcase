g++ -Wall -o cache cache.cpp
for i in $(seq 1 1000)  
do   
yourans="yourans/test$i.out"
chranswer="chrans/chr$i.out"
inputfile="input/input$i.in"
./cache <$inputfile >$yourans
if  diff $chranswer $yourans 
then
	echo "$i case passed"
else
	echo "$i case not the same! Maybe CHR is too stupid"
	break;
fi
done   
